# Online-Bus-Booking-System
HTML, CSS, PHP, MYSQL
Projectworlds Bus is an online bus ticket booking and reservation software, built on the powerful open source language PHP and MySQL with Bootstrap framework that allows you to manage your bus inventory, fares, routes, schedules as well as your entire back office. It is a powerful software designed with the main intention of generating a dynamic and automated system for all bus booking and reservation operations. The True Bus will promote your fleet management to new and existing customers through a range of options.

Online Bus Booking System Modules
ADMIN MODULE
AGENT MODULE
USER MODULE
Features of Online Bus Booking System
ADMIN MODULE 

Admin has overall control of the system. The main functions of admin are given below.

Bus Management

Route Management

Board Point Management

Drop Point Management

Promo Code management

Gallery

Add Agent

Cancellation

View Booking Details

Seat Layout

View Rating Details

Admin login
username - amit

password amit

USER MODULE

Can register or login
Book bus.
View and select the seat
Use  promo code
Book the ticket by selecting route, date of journey and the return date
View available buses
Payment integrated
Brief overview of the technology:
Front end: HTML, CSS, JavaScript

HTML: HTML is used to create and save web document. E.g. Notepad/Notepad++
CSS : (Cascading Style Sheets) Create attractive Layout
Bootstrap : responsive design mobile freindly site
JavaScript: it is a programming language, commonly use with web browsers.
Back end: PHP, MySQL

PHP: Hypertext Preprocessor (PHP) is a technology that allows software developers to create dynamically generated web pages, in HTML, XML, or other document types, as per client request. PHP is open source software.
MySQL: MySql is a database, widely used for accessing querying, updating, and managing data in databases.
Software Requirement(any one)
WAMP Server
XAMPP Server
MAMP Server
LAMP Server
Installation Steps
1. Download zip file and Unzip file on your local server.
2. Put this file inside "c:/wamp/www/" .
3. Database Configuration
Open phpmyadmin
Create Database named bus.
Import database bus.sql from downloaded folder(inside database)
4. Open Your browser put inside "http://localhost/Online Bus Booking System

Most Related Search

online bus booking system in php,
online bus booking system project in php,
online bus ticket booking system in php,
online bus seat booking system in php,
online bus booking system php mysql,
online bus ticket booking system project in php,
online bus pass booking system project in php,
online ticket booking system in php,
online movie ticket booking system in php,
online cinema ticket booking system in php,
online movie ticket booking system in php code,
online bus ticket booking system php source code,
online movie ticket booking system in php ppt,

visite https://projectworlds.in

#whatsapp 6263056779 